-- LeechsMarks v1.4.0
-- Auto-marks mobs in M+, marks tanks and healers in your group
-- by Leech

LeechsMarks = {}
local LM = LeechsMarks

local ICON_NAMES    = { [1]="Star",[2]="Circle",[3]="Diamond",[4]="Triangle",[5]="Moon",[6]="Square",[7]="Cross",[8]="Skull" }
local ICON_TEXTURES = {
    [1]="Interface\\TargetingFrame\\UI-RaidTargetingIcon_1",
    [2]="Interface\\TargetingFrame\\UI-RaidTargetingIcon_2",
    [3]="Interface\\TargetingFrame\\UI-RaidTargetingIcon_3",
    [4]="Interface\\TargetingFrame\\UI-RaidTargetingIcon_4",
    [5]="Interface\\TargetingFrame\\UI-RaidTargetingIcon_5",
    [6]="Interface\\TargetingFrame\\UI-RaidTargetingIcon_6",
    [7]="Interface\\TargetingFrame\\UI-RaidTargetingIcon_7",
    [8]="Interface\\TargetingFrame\\UI-RaidTargetingIcon_8",
}
local GITHUB_URL = "https://github.com/Leech/LeechsMarks"
local VERSION    = "1.4.0"

-- ── Defaults ──────────────────────────────────────────────────
local defaults = {
    enabled=true, markOnlyInParty=true, onlyUnmarked=true,
    autoMarkTanks=true,  tankMark=8,
    autoMarkHealers=true, healerMark=1,
    logoX=nil, logoY=nil,
    marks={[1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[7]=true,[8]=true},
}

-- ── State ─────────────────────────────────────────────────────
LM.db={}; LM.nextMark=1; LM.markedUnits={}; LM.markedRoles={}

-- ── DB init ───────────────────────────────────────────────────
local function InitDB()
    if not LeechsMarksDB then LeechsMarksDB={} end
    for k,v in pairs(defaults) do
        if LeechsMarksDB[k]==nil then
            if type(v)=="table" then
                LeechsMarksDB[k]={}
                for k2,v2 in pairs(v) do LeechsMarksDB[k][k2]=v2 end
            else
                LeechsMarksDB[k]=v
            end
        end
    end
    if not LeechsMarksDB.marks then
        LeechsMarksDB.marks={}
        for i=1,8 do LeechsMarksDB.marks[i]=true end
    end
    LM.db=LeechsMarksDB
end

-- ── Iterate group members ─────────────────────────────────────
local function ForEachMember(cb)
    if IsInRaid() then
        for i=1,GetNumGroupMembers() do
            local u="raid"..i
            if UnitExists(u) then cb(u) end
        end
    elseif IsInGroup() then
        cb("player")
        for i=1,GetNumGroupMembers()-1 do
            local u="party"..i
            if UnitExists(u) then cb(u) end
        end
    else
        cb("player")
    end
end

-- ── Role detection ────────────────────────────────────────────
-- GetSpecializationInfo(slotIndex)  -> id, name, desc, icon, role
-- GetSpecializationInfoByID(specID) -> id, name, desc, icon, role
-- Role is always the 5th return value.
-- Known Midnight spec IDs (from in-game debug: prot pala = 581)
-- We keep this as a safety net alongside the API calls
local MIDNIGHT_SPEC_ROLE = {
    -- TANKS (Midnight IDs - update as discovered)
    [581]="TANK",  -- Protection Paladin (confirmed from debug)
    -- HEALERS
}

local function GetUnitRole(unit)
    -- 1) Blizzard synced role
    local r = UnitGroupRolesAssigned(unit)
    if r and r~="NONE" and r~="" then return r end

    -- 2) Spec API (works when return values are correct)
    if unit=="player" then
        local idx=GetSpecialization()
        if idx then
            local r1,r2,r3,r4,r5,r6,r7=GetSpecializationInfo(idx)
            -- r5 should be role string, but also check r1 (specID) in our table
            if r5=="TANK"   or r5=="TANK_ROLE"   then return "TANK"   end
            if r5=="HEALER" or r5=="HEALER_ROLE" then return "HEALER" end
            if r6=="TANK"   or r6=="TANK_ROLE"   then return "TANK"   end
            if r6=="HEALER" or r6=="HEALER_ROLE" then return "HEALER" end
            -- Check specID against known table
            if r1 and MIDNIGHT_SPEC_ROLE[r1] then return MIDNIGHT_SPEC_ROLE[r1] end
        end
    else
        local specID=GetInspectSpecialization and GetInspectSpecialization(unit) or 0
        if specID and specID>0 then
            local _,_,_,_,role=GetSpecializationInfoByID(specID)
            if role=="TANK"   or role=="TANK_ROLE"   then return "TANK"   end
            if role=="HEALER" or role=="HEALER_ROLE" then return "HEALER" end
            if MIDNIGHT_SPEC_ROLE[specID] then return MIDNIGHT_SPEC_ROLE[specID] end
        end
    end
    return "NONE"
end

-- ── Debug printer ─────────────────────────────────────────────
local function DebugRoles()
    print("|cff00ccffLeechsMarks DEBUG:|r")
    print("  InGroup="..tostring(IsInGroup()).." InRaid="..tostring(IsInRaid()))
    print("  Leader="..tostring(UnitIsGroupLeader("player")).." Officer="..tostring(UnitIsRaidOfficer("player")))

    -- Raw dump of player spec API
    local idx=GetSpecialization()
    print("  GetSpecialization()="..tostring(idx))
    if idx then
        local r1,r2,r3,r4,r5,r6,r7=GetSpecializationInfo(idx)
        print("  GetSpecializationInfo("..idx.."):")
        print("    [1]="..tostring(r1).." [2]="..tostring(r2))
        print("    [3]="..tostring(r3).." [4]="..tostring(r4))
        print("    [5]="..tostring(r5).." [6]="..tostring(r6).." [7]="..tostring(r7))
    end

    ForEachMember(function(unit)
        local name=UnitName(unit) or "?"
        local bliz=UnitGroupRolesAssigned(unit) or "nil"
        local final=GetUnitRole(unit)
        local tm=LM.db.autoMarkTanks and LM.db.tankMark or nil
        local hm=LM.db.autoMarkHealers and LM.db.healerMark or nil
        print(string.format("  [%s] bliz=%s final=%s tm=%s hm=%s",name,bliz,final,tostring(tm),tostring(hm)))
    end)
end

-- ── Mark roles ────────────────────────────────────────────────
local function MarkGroupRoles(force)
    if not LM.db.enabled then return end
    if IsInGroup() or IsInRaid() then
        if not UnitIsGroupLeader("player") and not UnitIsRaidOfficer("player") then return end
    end
    local tankMark   = LM.db.autoMarkTanks   and (LM.db.tankMark   or 8) or nil
    local healerMark = LM.db.autoMarkHealers  and (LM.db.healerMark or 1) or nil
    ForEachMember(function(unit)
        local guid=UnitGUID(unit)
        if not guid then return end
        if not force and LM.markedRoles[guid] then return end
        local role=GetUnitRole(unit)
        if role=="NONE" and unit~="player" and CanInspect and CanInspect(unit) then
            NotifyInspect(unit)
        end
        local want=nil
        if   role=="TANK"   and tankMark   then want=tankMark
        elseif role=="HEALER" and healerMark then want=healerMark
        end
        if want then
            if GetRaidTargetIndex(unit)~=want then SetRaidTarget(unit,want) end
            LM.markedRoles[guid]=true
        end
    end)
end

local function MarkGroupRolesWithRetry()
    LM.markedRoles={}
    MarkGroupRoles(true)
    C_Timer.After(1.5,function() MarkGroupRoles(true) end)
    C_Timer.After(4.0,function() MarkGroupRoles(true) end)
    C_Timer.After(8.0,function() MarkGroupRoles(true) end)
end

-- ── Mob marking ───────────────────────────────────────────────
local function GetNextMark()
    local tm=LM.db.autoMarkTanks   and (LM.db.tankMark   or 8) or nil
    local hm=LM.db.autoMarkHealers  and (LM.db.healerMark or 1) or nil
    for i=0,7 do
        local idx=((LM.nextMark-1+i)%8)+1
        if LM.db.marks[idx] and idx~=tm and idx~=hm then return idx end
    end
end

local function MarkUnit(unit)
    if not LM.db.enabled then return end
    if LM.db.markOnlyInParty and not (IsInGroup() or IsInRaid()) then return end
    if not UnitExists(unit) then return end
    if UnitIsDeadOrGhost(unit) then return end
    if UnitIsFriend("player",unit) then return end
    if UnitIsPlayer(unit) then return end
    if LM.db.onlyUnmarked then
        local c=GetRaidTargetIndex(unit)
        if c and c>0 then return end
    end
    if (IsInGroup() or IsInRaid()) and not UnitIsGroupLeader("player") and not UnitIsRaidOfficer("player") then return end
    local idx=GetNextMark()
    if not idx then return end
    SetRaidTarget(unit,idx)
    LM.nextMark=(idx%8)+1
    local guid=UnitGUID(unit)
    if guid then LM.markedUnits[guid]=idx end
end

-- ── Events ────────────────────────────────────────────────────
local ev=CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("PLAYER_ENTERING_WORLD")
ev:RegisterEvent("PLAYER_TARGET_CHANGED")
ev:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
ev:RegisterEvent("GROUP_ROSTER_UPDATE")
ev:RegisterEvent("ROLE_CHANGED_INFORM")
ev:RegisterEvent("INSPECT_READY")
ev:SetScript("OnEvent",function(self,event,...)
    if event=="PLAYER_LOGIN" then
        InitDB()
        local ok,e=pcall(function() LM:CreateLogo() end)
        if not ok then print("|cffff4444LeechsMarks logo err:|r "..tostring(e)) end
        local ok2,e2=pcall(function() LM:CreateUI() end)
        if not ok2 then print("|cffff4444LeechsMarks UI err:|r "..tostring(e2)) end
        print("|cff00ccffLeechsMarks|r v"..VERSION.." loaded. |cffffcc00/lm|r to open.")
    elseif event=="PLAYER_ENTERING_WORLD" then
        LM.markedUnits={}; LM.markedRoles={}; LM.nextMark=1
        C_Timer.After(3,MarkGroupRolesWithRetry)
    elseif event=="GROUP_ROSTER_UPDATE" then
        MarkGroupRolesWithRetry()
    elseif event=="ROLE_CHANGED_INFORM" then
        LM.markedRoles={}
        C_Timer.After(0.5,function() MarkGroupRoles(true) end)
    elseif event=="INSPECT_READY" then
        C_Timer.After(0.1,function() MarkGroupRoles(false) end)
    elseif event=="PLAYER_TARGET_CHANGED" then
        if UnitExists("target") then MarkUnit("target") end
    elseif event=="COMBAT_LOG_EVENT_UNFILTERED" then
        local _,sub,_,_,_,_,_,dGUID=CombatLogGetCurrentEventInfo()
        if sub=="SPELL_DAMAGE" or sub=="RANGE_DAMAGE" or sub=="SWING_DAMAGE" or sub=="SPELL_PERIODIC_DAMAGE" then
            for i=1,40 do
                local u="nameplate"..i
                if UnitExists(u) and UnitGUID(u)==dGUID then MarkUnit(u); break end
            end
        end
    end
end)

local _el=0
local sf=CreateFrame("Frame")
sf:SetScript("OnUpdate",function(self,dt)
    _el=_el+dt; if _el<0.5 then return end; _el=0
    if not LM.db or not LM.db.enabled then return end
    for i=1,40 do local u="nameplate"..i; if UnitExists(u) then MarkUnit(u) end end
end)

-- ── Logo (always-visible draggable button) ────────────────────
function LM:CreateLogo()
    if LM.logo then return end
    local logo=CreateFrame("Button","LeechsMarksLogo",UIParent)
    logo:SetSize(36,36); logo:SetFrameStrata("HIGH")
    logo:SetMovable(true); logo:EnableMouse(true)
    logo:RegisterForDrag("LeftButton")
    logo:RegisterForClicks("RightButtonUp","LeftButtonUp")
    logo:SetClampedToScreen(true)

    local bg=logo:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints()
    bg:SetColorTexture(0.05,0.05,0.15,0.92)
    local ico=logo:CreateTexture(nil,"ARTWORK"); ico:SetSize(28,28); ico:SetPoint("CENTER")
    ico:SetTexture(ICON_TEXTURES[8])
    local glow=logo:CreateTexture(nil,"OVERLAY"); glow:SetAllPoints()
    glow:SetColorTexture(0,0.5,1,0)

    logo:SetScript("OnEnter",function(self)
        glow:SetColorTexture(0,0.5,1,0.25)
        GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
        GameTooltip:AddLine("|cff00ccffLeechsMarks|r v"..VERSION)
        GameTooltip:AddLine("|cffccccccLeft-click:|r Open/close settings")
        GameTooltip:AddLine("|cffccccccRight-click:|r Mark roles now")
        GameTooltip:AddLine("|cffccccccDrag:|r Move icon")
        GameTooltip:Show()
    end)
    logo:SetScript("OnLeave",function() glow:SetColorTexture(0,0.5,1,0); GameTooltip:Hide() end)
    logo:SetScript("OnDragStart",logo.StartMoving)
    logo:SetScript("OnDragStop",function(self)
        self:StopMovingOrSizing()
        local _,_,_,x,y=self:GetPoint()
        LM.db.logoX=x; LM.db.logoY=y
    end)
    logo:SetScript("OnClick",function(self,btn)
        if btn=="RightButton" then
            LM.markedRoles={}; MarkGroupRoles(true)
            C_Timer.After(1.5,function() MarkGroupRoles(true) end)
            print("|cff00ccffLeechsMarks:|r Marking roles...")
        else
            LM:ToggleUI()
        end
    end)
    if LM.db.logoX and LM.db.logoY then
        logo:SetPoint("BOTTOMLEFT",UIParent,"BOTTOMLEFT",LM.db.logoX,LM.db.logoY)
    else
        logo:SetPoint("BOTTOMRIGHT",UIParent,"BOTTOMRIGHT",-220,40)
    end
    LM.logo=logo
end

-- ── Main UI window ────────────────────────────────────────────
function LM:CreateUI()
    if LM.frame then return end

    local f=CreateFrame("Frame","LeechsMarksFrame",UIParent)
    f:SetSize(320,580); f:SetPoint("CENTER")
    f:SetMovable(true); f:EnableMouse(true)
    f:RegisterForDrag("LeftButton"); f:SetScript("OnDragStart",f.StartMoving)
    f:SetFrameStrata("DIALOG"); f:SetClampedToScreen(true); f:Hide()

    -- Background + border
    local fbg=f:CreateTexture(nil,"BACKGROUND"); fbg:SetAllPoints(); fbg:SetColorTexture(0.04,0.04,0.10,0.97)
    local function Edge(p1,p2) local t=f:CreateTexture(nil,"BORDER"); t:SetPoint(unpack(p1)); t:SetPoint(unpack(p2)); t:SetColorTexture(0.22,0.22,0.50,0.9) end
    Edge({"TOPLEFT",f,"TOPLEFT",0,-1},{"TOPRIGHT",f,"TOPRIGHT",0,-1})
    Edge({"BOTTOMLEFT",f,"BOTTOMLEFT",0,1},{"BOTTOMRIGHT",f,"BOTTOMRIGHT",0,1})
    Edge({"TOPLEFT",f,"TOPLEFT",0,0},{"BOTTOMLEFT",f,"BOTTOMLEFT",2,0})
    Edge({"TOPRIGHT",f,"TOPRIGHT",-2,0},{"BOTTOMRIGHT",f,"BOTTOMRIGHT",0,0})

    -- Title bar
    local tbar=f:CreateTexture(nil,"ARTWORK"); tbar:SetPoint("TOPLEFT",2,-2); tbar:SetPoint("TOPRIGHT",-2,-2); tbar:SetHeight(36); tbar:SetColorTexture(0.07,0.07,0.20,1)
    local tIco=f:CreateTexture(nil,"OVERLAY"); tIco:SetSize(22,22); tIco:SetPoint("TOPLEFT",12,-8); tIco:SetTexture(ICON_TEXTURES[8])
    local tTxt=f:CreateFontString(nil,"OVERLAY","GameFontHighlightLarge"); tTxt:SetPoint("TOPLEFT",40,-12)
    tTxt:SetText("|cff00ccffLeech|r|cffffffffsMarks|r  |cff444466v"..VERSION.."|r")
    local xBtn=CreateFrame("Button",nil,f); xBtn:SetSize(24,24); xBtn:SetPoint("TOPRIGHT",-6,-7)
    local xbg=xBtn:CreateTexture(nil,"ARTWORK"); xbg:SetAllPoints(); xbg:SetColorTexture(0.5,0.05,0.05,0.9)
    local xT=xBtn:CreateFontString(nil,"OVERLAY","GameFontNormal"); xT:SetPoint("CENTER"); xT:SetText("X"); xT:SetTextColor(1,0.5,0.5)
    xBtn:SetScript("OnClick",function() f:Hide() end)
    xBtn:SetScript("OnEnter",function() xbg:SetColorTexture(0.8,0.1,0.1,1) end)
    xBtn:SetScript("OnLeave",function() xbg:SetColorTexture(0.5,0.05,0.05,0.9) end)

    -- Divider under title
    local d0=f:CreateTexture(nil,"ARTWORK"); d0:SetPoint("TOPLEFT",2,-40); d0:SetPoint("TOPRIGHT",-2,-40); d0:SetHeight(1); d0:SetColorTexture(0.2,0.2,0.45,0.8)

    -- ── Tabs ──
    local TAB_Y=-44; local TAB_H=26
    local tabNames={"General","Roles","Mob Marks","Misc"}
    local tabs={}; local pages={}

    local tabW=(320-4)/#tabNames

    local function ShowTab(idx)
        for i,pg in ipairs(pages) do if i==idx then pg:Show() else pg:Hide() end end
        for i,t in ipairs(tabs) do
            if i==idx then t.bg:SetColorTexture(0.10,0.18,0.40,1); t.lbl:SetTextColor(1,1,1); t.line:SetColorTexture(0,0.55,1,1)
            else            t.bg:SetColorTexture(0.06,0.06,0.14,1); t.lbl:SetTextColor(0.5,0.5,0.62); t.line:SetColorTexture(0,0,0,0) end
        end
    end

    for i,name in ipairs(tabNames) do
        local tab=CreateFrame("Button",nil,f); tab:SetSize(tabW,TAB_H)
        tab:SetPoint("TOPLEFT",f,"TOPLEFT",2+(i-1)*tabW,TAB_Y)
        local tbg=tab:CreateTexture(nil,"BACKGROUND"); tbg:SetAllPoints()
        local tlbl=tab:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); tlbl:SetPoint("CENTER"); tlbl:SetText(name)
        local tline=tab:CreateTexture(nil,"OVERLAY"); tline:SetPoint("BOTTOMLEFT"); tline:SetPoint("BOTTOMRIGHT"); tline:SetHeight(3)
        tab:SetScript("OnClick",function() ShowTab(i) end)
        tabs[i]={bg=tbg,lbl=tlbl,line=tline}
        local pg=CreateFrame("Frame",nil,f)
        pg:SetPoint("TOPLEFT",f,"TOPLEFT",0,TAB_Y-TAB_H-2)
        pg:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",0,50); pg:Hide()
        pages[i]=pg
    end

    local dt=f:CreateTexture(nil,"ARTWORK"); dt:SetPoint("TOPLEFT",2,TAB_Y-TAB_H); dt:SetPoint("TOPRIGHT",-2,TAB_Y-TAB_H); dt:SetHeight(1); dt:SetColorTexture(0.2,0.2,0.45,0.5)

    -- Bottom bar
    local db=f:CreateTexture(nil,"ARTWORK"); db:SetPoint("BOTTOMLEFT",2,48); db:SetPoint("BOTTOMRIGHT",-2,48); db:SetHeight(1); db:SetColorTexture(0.2,0.2,0.45,0.5)

    local markAllBtn=CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
    markAllBtn:SetSize(160,26); markAllBtn:SetPoint("BOTTOMLEFT",10,14); markAllBtn:SetText("Mark All Roles")
    markAllBtn:SetScript("OnClick",function()
        DebugRoles()
        LM.markedRoles={}; MarkGroupRoles(true)
        C_Timer.After(1.5,function() MarkGroupRoles(true) end)
        print("|cff00ccffLeechsMarks:|r Marking roles...")
    end)
    local resetBtn=CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
    resetBtn:SetSize(100,26); resetBtn:SetPoint("BOTTOMRIGHT",-10,14); resetBtn:SetText("Reset Cycle")
    resetBtn:SetScript("OnClick",function() LM.nextMark=1; LM.markedUnits={}; print("|cff00ccffLeechsMarks:|r Cycle reset.") end)

    -- ── Helpers ──
    local function Div(p,y) local d=p:CreateTexture(nil,"ARTWORK"); d:SetPoint("TOPLEFT",4,y); d:SetPoint("TOPRIGHT",-4,y); d:SetHeight(1); d:SetColorTexture(0.15,0.15,0.38,0.5) end
    local function SLbl(p,txt,y) local l=p:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); l:SetPoint("TOPLEFT",12,y); l:SetText("|cff7799ff"..txt.."|r") end
    local function Chk(p,lbl,y,getV,setV,tip)
        local box=CreateFrame("Button",nil,p); box:SetSize(20,20); box:SetPoint("TOPLEFT",12,y)
        local bbg=box:CreateTexture(nil,"BACKGROUND"); bbg:SetAllPoints()
        local chk=box:CreateTexture(nil,"OVERLAY"); chk:SetSize(14,14); chk:SetPoint("CENTER"); chk:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
        local brd=box:CreateTexture(nil,"BORDER"); brd:SetAllPoints(); brd:SetColorTexture(0.35,0.35,0.6,0.7)
        local function Ref()
            if getV() then bbg:SetColorTexture(0,0.38,0.85,0.9); chk:Show()
            else bbg:SetColorTexture(0.12,0.12,0.18,0.95); chk:Hide() end
            box:SetNormalTexture(""); box:SetHighlightTexture("")
        end
        Ref()
        box:SetScript("OnClick",function() setV(); Ref() end)
        if tip then
            box:SetScript("OnEnter",function(s) GameTooltip:SetOwner(s,"ANCHOR_RIGHT"); GameTooltip:SetText(tip,nil,nil,nil,nil,true); GameTooltip:Show() end)
            box:SetScript("OnLeave",function() GameTooltip:Hide() end)
        end
        local l=p:CreateFontString(nil,"OVERLAY","GameFontNormal"); l:SetPoint("LEFT",box,"RIGHT",8,0); l:SetText(lbl); l:SetTextColor(0.86,0.86,0.94)
    end
    local function IconPick(p,sx,sy,getS,onS)
        local sz=30; local pd=5; local btns={}
        local function RefAll()
            local sel=getS()
            for i,b in ipairs(btns) do
                if sel==i then b.bg:SetColorTexture(0,0.35,0.8,0.85); b.brd:SetColorTexture(0,0.6,1,0.8); b.ico:SetDesaturated(false); b.ico:SetAlpha(1)
                else b.bg:SetColorTexture(0.1,0.1,0.12,0.95); b.brd:SetColorTexture(0.25,0.25,0.3,0.5); b.ico:SetDesaturated(true); b.ico:SetAlpha(0.4) end
            end
        end
        for i=1,8 do
            local col=(i-1)%4; local row=math.floor((i-1)/4)
            local btn=CreateFrame("Button",nil,p); btn:SetSize(sz,sz)
            btn:SetPoint("TOPLEFT",p,"TOPLEFT",sx+col*(sz+pd),sy-row*(sz+pd))
            local bg=btn:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints()
            local brd=btn:CreateTexture(nil,"BORDER"); brd:SetAllPoints()
            local ico=btn:CreateTexture(nil,"ARTWORK"); ico:SetSize(sz-8,sz-8); ico:SetPoint("CENTER"); ico:SetTexture(ICON_TEXTURES[i])
            btns[i]={bg=bg,brd=brd,ico=ico}
            btn:SetScript("OnClick",function() onS(i); RefAll() end)
            btn:SetScript("OnEnter",function(s) GameTooltip:SetOwner(s,"ANCHOR_RIGHT"); GameTooltip:SetText(ICON_NAMES[i],nil,nil,nil,nil,true); GameTooltip:Show() end)
            btn:SetScript("OnLeave",function() GameTooltip:Hide() end)
        end
        RefAll()
    end

    -- ════ PAGE 1: GENERAL ════
    local p1=pages[1]; local y=-10
    Chk(p1,"Auto Mark Enabled",y,function() return LM.db.enabled end,function() LM.db.enabled=not LM.db.enabled end,"Master on/off for all marking."); y=y-36
    Chk(p1,"Only mark when in a group",y,function() return LM.db.markOnlyInParty end,function() LM.db.markOnlyInParty=not LM.db.markOnlyInParty end,"Skip mob marking when solo."); y=y-36
    Chk(p1,"Skip already-marked units",y,function() return LM.db.onlyUnmarked end,function() LM.db.onlyUnmarked=not LM.db.onlyUnmarked end,"Don't overwrite existing marks."); y=y-44
    Div(p1,y); y=y-14

    local stLbl=p1:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); stLbl:SetPoint("TOPLEFT",12,y); stLbl:SetWidth(285)
    p1:SetScript("OnShow",function()
        local inG=IsInGroup() or IsInRaid()
        local lead=UnitIsGroupLeader("player") or UnitIsRaidOfficer("player")
        local s=inG and ("|cff00ff00In group|r ("..GetNumGroupMembers().." members)") or "|cffff8800Not in a group|r"
        local s2=inG and (lead and "\n|cff00ff00Can set marks|r" or "\n|cffff4444Need leader/assist to mark|r") or ""
        stLbl:SetText(s..s2)
    end)

    -- ════ PAGE 2: ROLES ════
    local p2=pages[2]; y=-10
    SLbl(p2,"TANKS",y); y=y-22
    Chk(p2,"Auto-mark group tanks",y,function() return LM.db.autoMarkTanks end,function() LM.db.autoMarkTanks=not LM.db.autoMarkTanks; LM.markedRoles={}; MarkGroupRoles(true) end,"Assign icon to tanks."); y=y-36
    local tL=p2:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); tL:SetPoint("TOPLEFT",12,y); tL:SetText("|cff888888Tank icon:|r"); y=y-20
    IconPick(p2,12,y,function() return LM.db.tankMark end,function(i) LM.db.tankMark=i; LM.markedRoles={}; MarkGroupRoles(true) end)
    y=y-78
    Div(p2,y); y=y-12
    SLbl(p2,"HEALERS",y); y=y-22
    Chk(p2,"Auto-mark group healers",y,function() return LM.db.autoMarkHealers end,function() LM.db.autoMarkHealers=not LM.db.autoMarkHealers; LM.markedRoles={}; MarkGroupRoles(true) end,"Assign icon to healers."); y=y-36
    local hL=p2:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); hL:SetPoint("TOPLEFT",12,y); hL:SetText("|cff888888Healer icon:|r"); y=y-20
    IconPick(p2,12,y,function() return LM.db.healerMark end,function(i) LM.db.healerMark=i; LM.markedRoles={}; MarkGroupRoles(true) end)
    y=y-78
    Div(p2,y); y=y-12

    local riLbl=p2:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); riLbl:SetPoint("TOPLEFT",12,y); riLbl:SetWidth(285); riLbl:SetText("|cff666688Open tab to refresh.|r")
    p2:SetScript("OnShow",function()
        local lines={}
        ForEachMember(function(unit)
            local name=UnitName(unit) or "?"
            local role=GetUnitRole(unit)
            local c=role=="TANK" and "|cffff9900" or (role=="HEALER" and "|cff00dd88" or "|cff777777")
            table.insert(lines,c..name..": "..role.."|r")
        end)
        riLbl:SetText(#lines>0 and table.concat(lines,"\n") or "|cff666688No members.|r")
    end)

    -- ════ PAGE 3: MOB MARKS ════
    local p3=pages[3]; y=-10
    local mi=p3:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); mi:SetPoint("TOPLEFT",12,y); mi:SetWidth(285)
    mi:SetText("|cff888888Toggle icons for enemies. Orange = reserved for roles.|r"); y=y-30
    local isz=48; local ipd=8; local mobBtns={}
    local function RefMob()
        local tm=LM.db.autoMarkTanks and LM.db.tankMark or nil
        local hm=LM.db.autoMarkHealers and LM.db.healerMark or nil
        for i,b in ipairs(mobBtns) do
            local res=(i==tm) or (i==hm)
            local on=LM.db.marks[i] and not res
            if res then b.bg:SetColorTexture(0.28,0.10,0,0.9); b.brd:SetColorTexture(0.8,0.3,0,0.6); b.ico:SetDesaturated(false); b.ico:SetAlpha(0.65); b.lbl:SetTextColor(0.85,0.45,0.1)
            elseif on then b.bg:SetColorTexture(0,0.32,0.78,0.85); b.brd:SetColorTexture(0,0.6,1,0.6); b.ico:SetDesaturated(false); b.ico:SetAlpha(1); b.lbl:SetTextColor(0.55,0.85,1)
            else b.bg:SetColorTexture(0.10,0.10,0.12,0.95); b.brd:SetColorTexture(0.22,0.22,0.28,0.5); b.ico:SetDesaturated(true); b.ico:SetAlpha(0.38); b.lbl:SetTextColor(0.38,0.38,0.42) end
        end
    end
    for i=1,8 do
        local col=(i-1)%4; local row=math.floor((i-1)/4)
        local btn=CreateFrame("Button",nil,p3); btn:SetSize(isz,isz)
        btn:SetPoint("TOPLEFT",p3,"TOPLEFT",12+col*(isz+ipd),y-row*(isz+ipd))
        local bg=btn:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints()
        local ico=btn:CreateTexture(nil,"ARTWORK"); ico:SetSize(30,30); ico:SetPoint("CENTER",0,5); ico:SetTexture(ICON_TEXTURES[i])
        local lbl=btn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); lbl:SetPoint("BOTTOM",0,3); lbl:SetText(ICON_NAMES[i]); lbl:SetFont("Fonts\\FRIZQT__.TTF",8)
        local brd=btn:CreateTexture(nil,"BORDER"); brd:SetAllPoints()
        mobBtns[i]={bg=bg,ico=ico,lbl=lbl,brd=brd}
        btn:SetScript("OnClick",function()
            local tm2=LM.db.autoMarkTanks and LM.db.tankMark or nil
            local hm2=LM.db.autoMarkHealers and LM.db.healerMark or nil
            if i==tm2 or i==hm2 then print("|cff00ccffLeechsMarks:|r Reserved for role."); return end
            LM.db.marks[i]=not LM.db.marks[i]; RefMob()
        end)
        btn:SetScript("OnEnter",function(self)
            local tm2=LM.db.autoMarkTanks and LM.db.tankMark or nil
            local hm2=LM.db.autoMarkHealers and LM.db.healerMark or nil
            GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
            local info=i==tm2 and "|cffff9900Reserved-Tank|r" or (i==hm2 and "|cff00dd88Reserved-Healer|r" or (LM.db.marks[i] and "|cff00ff00Enabled|r" or "|cffff4444Disabled|r"))
            GameTooltip:SetText(ICON_NAMES[i].."\n"..info,nil,nil,nil,nil,true); GameTooltip:Show()
        end)
        btn:SetScript("OnLeave",function() RefMob(); GameTooltip:Hide() end)
    end
    RefMob(); p3:SetScript("OnShow",RefMob)

    -- ════ PAGE 4: MISC ════
    local p4=pages[4]; y=-14
    local bigIco=p4:CreateTexture(nil,"ARTWORK"); bigIco:SetSize(44,44); bigIco:SetPoint("TOPLEFT",12,y); bigIco:SetTexture(ICON_TEXTURES[8])
    local bT=p4:CreateFontString(nil,"OVERLAY","GameFontHighlightLarge"); bT:SetPoint("LEFT",bigIco,"RIGHT",10,5); bT:SetText("|cff00ccffLeech|r|cffffffffsMarks|r")
    local bS=p4:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); bS:SetPoint("LEFT",bigIco,"RIGHT",10,-8); bS:SetText("|cff555577v"..VERSION.."  by Leech  WoW Midnight|r")
    y=y-60
    Div(p4,y); y=y-14
    local ghT=p4:CreateFontString(nil,"OVERLAY","GameFontNormal"); ghT:SetPoint("TOPLEFT",12,y); ghT:SetText("|cff00ccffGitHub|r"); y=y-22
    local ghU=p4:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); ghU:SetPoint("TOPLEFT",12,y); ghU:SetText("|cff4499ff"..GITHUB_URL.."|r"); y=y-24
    local cpB=CreateFrame("Button",nil,p4,"UIPanelButtonTemplate"); cpB:SetSize(170,26); cpB:SetPoint("TOPLEFT",12,y); cpB:SetText("Print URL to Chat")
    cpB:SetScript("OnClick",function() DEFAULT_CHAT_FRAME:AddMessage("|cff00ccffLeechsMarks:|r "..GITHUB_URL) end)
    y=y-40; Div(p4,y); y=y-14
    local nT=p4:CreateFontString(nil,"OVERLAY","GameFontNormal"); nT:SetPoint("TOPLEFT",12,y); nT:SetText("|cff888888Notes|r"); y=y-20
    local nB=p4:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); nB:SetPoint("TOPLEFT",12,y); nB:SetWidth(286)
    nB:SetText("|cff555577Role marks retry at 1.5s/4s/8s after join\nRight-click logo = force re-mark\nNeed leader/assist to mark in groups\nOrange icons = reserved for roles|r")

    f:SetScript("OnDragStop",function(self)
        self:StopMovingOrSizing()
        local _,_,_,x,y2=self:GetPoint(); LM.db.posX=x; LM.db.posY=y2
    end)
    LM.frame=f
    ShowTab(1)
end

-- ── Toggle ────────────────────────────────────────────────────
function LM:ToggleUI()
    if not LM.frame then
        if LM.db and next(LM.db) then
            local ok,e=pcall(function() LM:CreateUI() end)
            if not ok then print("|cffff4444LeechsMarks UI err:|r "..tostring(e)); return end
        else print("|cff00ccffLeechsMarks:|r Not ready."); return end
    end
    if LM.frame:IsShown() then LM.frame:Hide() else LM.frame:Show() end
end

-- ── Slash commands ────────────────────────────────────────────
SLASH_LEECHSMARKS1="/leechsmarks"
SLASH_LEECHSMARKS2="/lm"
SlashCmdList["LEECHSMARKS"]=function(msg)
    local cmd=msg:lower():trim()
    if cmd=="" or cmd=="toggle" then LM:ToggleUI()
    elseif cmd=="enable"  then LM.db.enabled=true;  print("|cff00ccffLeechsMarks:|r |cff00ff00Enabled|r.")
    elseif cmd=="disable" then LM.db.enabled=false; print("|cff00ccffLeechsMarks:|r |cffff4444Disabled|r.")
    elseif cmd=="reset"   then LM.nextMark=1; LM.markedUnits={}; print("|cff00ccffLeechsMarks:|r Cycle reset.")
    elseif cmd=="roles"   then DebugRoles(); LM.markedRoles={}; MarkGroupRoles(true); C_Timer.After(1.5,function() MarkGroupRoles(true) end); print("|cff00ccffLeechsMarks:|r Marking roles...")
    elseif cmd=="debug"   then DebugRoles()
    else print("|cff00ccffLeechsMarks|r: /lm [enable|disable|reset|roles|debug]") end
end
